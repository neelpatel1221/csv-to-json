export interface User {
  name: string;
  age: number;
  address: Record<string, any>;
  additional_info: Record<string, any>;
}
