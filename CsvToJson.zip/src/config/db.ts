import {Pool} from 'pg'
import dotenv from "dotenv";
import { User } from '../types/User';
dotenv.config();

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

pool.on("connect", (client) => {
  client.on("notice", (msg) => console.log("NOTICE:", msg));
  client.on("error", (err) => console.error("Client error:", err));
});

pool.on("error", (err) => {
  console.error("Unexpected error on idle client", err);
  process.exit(-1); // or handle gracefully
});

process.on("SIGINT", async () => {
  console.log("Shutting down gracefully...");
  await pool.end();
  process.exit(0);
});


export async function createUsersTable() {

    const query = `
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        age INT NOT NULL,
        address JSONB,
        additional_info JSONB
      );
    `;

  try {
    await pool.query(query);
    console.log("Users table is ready");
  } catch (err) {
    console.error("Failed to create users table:", err);
  }
}

export async function insertUsers(users: User[]){
    const client = await pool.connect();
    const batchSize = 1000
    try {
        await client.query('BEGIN')
        for (let i = 0; i < users.length; i += batchSize) {
            const chunk = users.slice(i, i + batchSize)

            const values: any= []
            const placeholders: string[] = []

            chunk.forEach((user, idx)=>{
                const baseIndex = idx * 4
                placeholders.push(
                  `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${
                    baseIndex + 4
                  })`
                )
                values.push(user.name, user.age, user.address, user.additional_info)
            })

            const query = 
            `INSERT INTO users (name, age, address, additional_info) VALUES 
            ${placeholders.join(', ')}`;

            await client.query(query, values);
        }
        await client.query("COMMIT");


    } catch (error) {
        console.log(error);
        await client.query("ROLLBACK");
    }
    finally{
        client.release();
    }
}

export async function printAgeDistribution() {
  const client = await pool.connect();

  try {
    const query = `
        SELECT
          COUNT(*) AS total,
          COUNT(*) FILTER (WHERE age < 20) AS age_lt_20,
          COUNT(*) FILTER (WHERE age BETWEEN 20 AND 40) AS age_20_40,
          COUNT(*) FILTER (WHERE age > 40 AND age <= 60) AS age_40_60,
          COUNT(*) FILTER (WHERE age > 60) AS age_gt_60
        FROM users;
      `;

    const result = await client.query(query);
    const row = result.rows[0];

    const total = parseInt(row.total, 10);
    const ageGroups = {
      "< 20": parseInt(row.age_lt_20, 10),
      "20 to 40": parseInt(row.age_20_40, 10),
      "40 to 60": parseInt(row.age_40_60, 10),
      "> 60": parseInt(row.age_gt_60, 10),
    };
    
    const ageGroupPercentages = Object.entries(ageGroups).map(
      ([group, count]) => {
        const percentage = total === 0 ? 0 : ((count / total) * 100).toFixed(2);
        return {
          "Age Group": group,
          Count: count,
          Percentage: `${percentage}%`,
        };
      }
    );
    console.table(ageGroupPercentages)
  } catch (err) {
    console.error(err);
  } finally {
    client.release();
  }
}
  